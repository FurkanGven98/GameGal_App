package com.example.gamegal_app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Sign_up : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)
    }
}